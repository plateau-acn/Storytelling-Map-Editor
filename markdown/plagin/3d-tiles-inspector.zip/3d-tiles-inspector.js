reearth.ui.show(
  `
  <style>
    html,body {
      display: none;
      margin: 0;
      width: 540px; 
      height: 545px; 
    }
    .base-frame {
      background-color: rgb(217, 217, 217);
      font: 16px sans-serif;
      color: rgb(67, 67, 67);
      width: 100%;
      box-shadow: rgba(0, 0, 0, 0.25) 0px 4px 4px;
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      transition: all 0.6s ease 0s;
      overflow: hidden;
    }
    .css-4lsfum {
      width: 16px;
      height: 16px;
      position: absolute;
      top: 10px;
      right: 10px;
      cursor: pointer;
      color: rgba(67, 67, 67, 0.5);
      display: block;
    }
    .data-set-frame {
      margin-top: 40px;
      overflow: auto;
      flex: 1 1 auto;
      font-size: 14px;
      transition: all 0.2s linear 0s;
      max-height: 80vh;
      padding: 20px 15px;
    }
    .data-set {
      display: block;
      background: rgb(244, 244, 244);
      margin-bottom: 6px;
      box-shadow: rgba(0, 0, 0, 0.25) 1px 2px 4px;
      overflow: hidden;
      transition: all 0.25s ease 0s;
      border-radius: 4px !important;
    }
    .data-title-frame {
      display: flex;
      align-items: flex-end;
      height: 30px;
      padding: 8px 16px;
      background-color: rgb(255, 255, 255);
      border-bottom: 1px solid rgb(224, 224, 224);
      font-size: 16px;
      line-height: 22px;
    }
    .build-info-frame {
      padding: 12px 16px;
      background-color: rgb(255, 255, 255);
    }
    .item-common {
      display: flex;
      align-items: flex-start;
      min-height: 32px;
      padding: 12px 0px 4px;
      gap: 12px;
      border-bottom: 1px solid rgb(217, 217, 217);
      font-size: 14px;
    }
    .item-field {
      width: 50%;
    }
    .item-data {
      width: 50%;
      word-break: break-all;
    }
    .json-frame {
      padding: 8px 0px;
      font-family: monospace;
      cursor: default;
      background-color: rgba(0, 0, 0, 0);
      position: relative;
    }
    .jsoneditor-field,
    .jsoneditor-readonly,
    .jsoneditor-value {
      color: rgb(67, 67, 67) !important;
      font-family: Roboto, sans-serif !important;
    }
    .jsoneditor {
      border-color: white;
    }
  </style>
  <link
    href="https://cdn.jsdelivr.net/npm/jsoneditor@9.10.3/dist/jsoneditor.min.css"
    rel="stylesheet"
  />
  <script src="https://cdn.jsdelivr.net/npm/jsoneditor@9.10.3/dist/jsoneditor.min.js"></script>
  <script>
    function clearAndAddNewStructure() {
      const buildInfoFrame = document.querySelector('.build-info-frame');

      const jsonFrame = buildInfoFrame.querySelector('.json-frame');

      while (buildInfoFrame.firstChild && buildInfoFrame.firstChild !== jsonFrame) {
          buildInfoFrame.removeChild(buildInfoFrame.firstChild);
      }
    }

    function closeWidget() {
      document.body.style.display = 'none';
      document.documentElement.style.display = 'none';
    }

    function openWidget() {
      document.body.style.display = 'block';
      document.documentElement.style.display = 'block';
      var element = document.getElementsByClassName('data-set-frame')[0];
      element.scrollTo(0,0);
    }

    function generateComponents(constantArray, newArray, layers) {
      let components = [];
      constantArray.forEach(item => {
        if (newArray.includes(item)) {
          components.push('<div class="item-common">');
          components.push('<div class="item-field">' + item + '</div>');
          components.push('<div class="item-data">' + layers[item] + '</div>');
          components.push('</div>');
        }
      });
      newArray.forEach(item => {
        if (!constantArray.includes(item) && item !== 'attributes') {
          components.push('<div class="item-common">');
          components.push('<div class="item-field">' + item + '</div>');
          components.push('<div class="item-data">' + layers[item] + '</div>');
          components.push('</div>');
        }
      });
      return components.join('');
    }

    function insertComponentsIntoBuildInfoFrame(componentsHTML) {
      const buildInfoFrame = document.querySelector('.build-info-frame');
      const divElement = document.createElement('div');
      divElement.innerHTML = componentsHTML;
      const jsonFrame = buildInfoFrame.querySelector('.json-frame');
      buildInfoFrame.insertBefore(divElement, jsonFrame);
    }

    const constantArray = ['gml_id', '名称', '用途', '住所', '計測高さ', '地上階数', '地下階数', '耐火構造種別', '地域地区', '調査年', '建物利用現況（詳細分類）', '建物ID', '図上面積', 'LOD1立ち上げに使用する高さ'];

    let container = document.getElementById("jsoneditor");
    let options = {
      mode: "view",
      name: "全ての属性",
      navigationBar: false,
      mainMenuBar: false,
    };
    let editor = new JSONEditor(container, options);
    let layers;
    window.addEventListener("message", function (e) {
      if (e.source !== parent) return;
      if(e.data.layer) {
          openWidget();
          layers = e.data.layer;
          var rootItem = Object.keys(layers);
          editor.set(layers);
          clearAndAddNewStructure();
          const componentsHTML = generateComponents(constantArray, rootItem, layers);
          insertComponentsIntoBuildInfoFrame(componentsHTML);
      } else {
        closeWidget();
      }
    });
  </script>
  <div class='base-frame'>
    <svg onclick="closeWidget()" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="css-4lsfum" color="#43434380" style="transition-duration: 0.3s;">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M12 10.5858L17.2929 5.29289C17.6834 4.90237 18.3166 4.90237 18.7071 5.29289C19.0976 5.68342 19.0976 6.31658 18.7071 6.70711L13.4142 12L18.7071 17.2929C19.0976 17.6834 19.0976 18.3166 18.7071 18.7071C18.3166 19.0976 17.6834 19.0976 17.2929 18.7071L12 13.4142L6.70711 18.7071C6.31658 19.0976 5.68342 19.0976 5.29289 18.7071C4.90237 18.3166 4.90237 17.6834 5.29289 17.2929L10.5858 12L5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L12 10.5858Z" fill="currentColor">
      </path>
    </svg>
    <div class='data-set-frame'>
      <div class="data-set">
        <div class='data-title-frame'>
          建築物モデル
        </div>
        <div class='build-info-frame'>
          <div class='json-frame'>
            <div id="jsoneditor"></div>
          </div>
        </div>
      </div>
    <div>
  </div>
`
);

reearth.on("select", send);

function send() {
  if (reearth.layers.selectedFeature) {
    if (reearth.layers.selectedFeature["3dtiles"]) {
      reearth.ui.postMessage({
        layer: reearth.layers.selectedFeature.properties,
      });
    } else {
      reearth.ui.postMessage({
        layer: false,
      });
    }
  } else {
    reearth.ui.postMessage({
      layer: false,
    });
  }
}
